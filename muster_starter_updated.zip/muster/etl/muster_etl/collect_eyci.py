import csv, io, os, requests
from datetime import datetime

# Configure a direct CSV endpoint for EYCI in ENV (preferred):
#   MLA_EYCI_URL=https://.../eyci.csv
# CSV must include columns: date,value OR Date,Price
MLA_EYCI_URL = os.getenv("MLA_EYCI_URL")

def _parse_csv(content: bytes):
    text = content.decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(text))
    rows = []
    for row in reader:
        # Try common headers
        date_key = next((k for k in row.keys() if k.lower() in ("date","as_of")), None)
        value_key = next((k for k in row.keys() if k.lower() in ("value","price","eyci","eyci_c_per_kg")), None)
        if not date_key or not value_key:
            continue
        d = row[date_key].strip()
        v = row[value_key].strip().replace(",","")
        try:
            # Normalize date to YYYY-MM-DD
            try:
                dt = datetime.strptime(d[:10], "%Y-%m-%d")
            except ValueError:
                # Try AU format
                dt = datetime.strptime(d[:10], "%d/%m/%Y")
            val = float(v)
            rows.append((dt.date().isoformat(), val))
        except Exception:
            continue
    rows.sort(key=lambda x: x[0])
    return rows

def run():
    if not MLA_EYCI_URL:
        # Fallback stub (replace in production)
        today = datetime.utcnow().date().isoformat()
        return {
            "series": "eyci",
            "value": 815.2,
            "as_of": today,
            "source_name": "Meat & Livestock Australia",
            "source_url": "https://www.mla.com.au",
            "calc_notes": "Stub EYCI (set MLA_EYCI_URL to wire live feed)",
            "history": []
        }
    r = requests.get(MLA_EYCI_URL, timeout=30)
    r.raise_for_status()
    rows = _parse_csv(r.content)
    if not rows:
        raise RuntimeError("EYCI CSV parsed empty")
    as_of, value = rows[-1]
    # Use last 30 rows as history
    history = rows[-30:]
    return {
        "series": "eyci",
        "value": value,
        "as_of": as_of,
        "source_name": "Meat & Livestock Australia",
        "source_url": MLA_EYCI_URL,
        "calc_notes": "Parsed from MLA EYCI CSV",
        "history": history
    }
