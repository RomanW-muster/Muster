def generate(series_map: dict) -> str:
    parts = []
    aud = series_map.get("audusd", {})
    if aud:
        d = aud.get("delta_d")
        val = aud.get("value")
        if d is not None and abs(d) < 0.2:
            parts.append(f"AUD steady around {val:.3f} USD.")
        elif d is not None:
            parts.append(f"AUD/USD {('up' if d>0 else 'down')} to {val:.3f} ({d:+.1f}%).")
    eyci = series_map.get("eyci", {})
    if eyci:
        dd = eyci.get("delta_d")
        val = eyci.get("value")
        if dd is not None:
            parts.append(f"EYCI {('rose' if dd>0 else 'eased')} {dd:+.1f} to {val:.1f} c/kg.")
    # Add more series summaries as needed
    text = " ".join(parts) or "Quiet session across markets."
    return text[:300]
