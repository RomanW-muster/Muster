# Muster — Starter Repo (V1)

This is a production-ready **starter** for the Muster dashboard: a static frontend and a Python ETL that publishes JSON/CSV/PNG data.

## Quick Start

### Frontend (static)
- Files under `frontend/` can be deployed on **Netlify**, **Vercel (static)**, **Cloudflare Pages**, or **S3+CloudFront**.
- The dashboard loads JSON from `frontend/data/*.json`. In production, point to your public bucket or CDN (update `assets/app.js` → `DATA_BASE_URL`).

### ETL (Python)
- Code under `etl/`. It runs collectors, validates, writes `frontend/data/` outputs (JSON/CSV) and tiny PNG sparklines (optional).
- Install: `cd etl && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
- Run locally: `python -m muster_etl.publish`
- Configure Slack webhook, S3, etc in `.env` (see `.env.example`).

### CI / Scheduler
- GitHub Actions workflow at `etl/.github/workflows/publish.yml` runs daily at **06:00 Australia/Sydney**.
- It commits updated files back to the repo (simple mode) OR uploads to S3/Cloudflare R2 (configure secrets and uncomment steps).

## Structure

```
muster/
├─ frontend/                # Static site
│  ├─ index.html            # Home (cards + Daily Wrap)
│  ├─ learn.html, about.html, contact.html
│  ├─ markets/              # Category pages
│  ├─ assets/
│  │  ├─ styles.css
│  │  └─ app.js             # Card renderer + data loader
│  └─ data/                 # JSON/CSV/PNG published by ETL
├─ etl/
│  ├─ muster_etl/
│  │  ├─ collect_audusd.py
│  │  ├─ collect_eyci.py    # stub; swap for MLA API
│  │  ├─ daily_wrap.py
│  │  ├─ publish.py
│  │  └─ schema.json
│  ├─ requirements.txt
│  ├─ .env.example
│  └─ .github/workflows/publish.yml
└─ README.md
```

## Notes
- **Data sources:** replace stubs with your preferred licensed feeds (MLA for EYCI, BOM for rainfall, etc.).
- **JSON schema** enforces required fields for auditable outputs.
- **No financial advice** — see footer on site.
