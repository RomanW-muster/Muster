import os, json, sys
from datetime import date, timedelta
from pathlib import Path
from jsonschema import validate
from dotenv import load_dotenv

from . import collect_audusd, collect_eyci, collect_urea, collect_diesel, collect_rainfall, daily_wrap

load_dotenv()

OUTPUT_DIR = Path(os.getenv("DATA_OUTPUT_DIR", "../frontend/data")).resolve()
SCHEMA_PATH = Path(__file__).with_name("schema.json")

SERIES_META = {
    "audusd": {"title": "AUD/USD Exchange Rate", "unit": "USD"},
    "eyci":   {"title": "Eastern Young Cattle Indicator", "unit": "c/kg dressed"},
    "urea":   {"title": "Urea (Landed AU est.)", "unit": "AUD/t"},
    "diesel": {"title": "Diesel (AU retail est.)", "unit": "AUD/L"},
    "rainfall": {"title": "Rainfall (7-day AUS)", "unit": "mm"},
}

COLLECTORS = {
    "audusd": collect_audusd,
    "eyci": collect_eyci,
    "urea": collect_urea,
    "diesel": collect_diesel,
    "rainfall": collect_rainfall,
}

def load_schema():
    with open(SCHEMA_PATH) as f:
        return json.load(f)

def load_last(slug: str):
    p = OUTPUT_DIR / f"{slug}.json"
    if p.exists():
        with open(p) as f:
            return json.load(f)
    return None

def write_csv(slug, history):
    csv_path = OUTPUT_DIR / "csv" / f"{slug}.csv"
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with open(csv_path, "w") as f:
        f.write("date,value\n")
        for d, v in history:
            f.write(f"{d},{v}\n")

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    schema = load_schema()
    results = {}
    today = date.today().isoformat()
    one_year_ago = (date.today() - timedelta(days=365)).isoformat()

    for slug, mod in COLLECTORS.items():
        try:
            data = mod.run()
        except Exception as e:
            print(f"[WARN] Collector failed {slug}: {e}", file=sys.stderr)
            data = None
        if data is None:
            # fallback to last
            data = load_last(slug) or {"series": slug, "value": None, "as_of": today, "history": []}
        # attach meta
        data["series"] = slug
        data["title"] = SERIES_META.get(slug, {}).get("title", slug)
        data["unit"] = SERIES_META.get(slug, {}).get("unit", "")
        data["as_of"] = data.get("as_of") or today

        # history: append today (dedupe) and trim to last 30
        hist = data.get("history") or []
        hist = [h for h in hist if h[0] != today]
        if data.get("value") is not None:
            hist.append([today, data["value"]])
        hist = hist[-30:]
        data["history"] = hist

        # deltas
        data["delta_d"] = None
        if len(hist) >= 2 and hist[-2][1] not in (None, 0):
            data["delta_d"] = (hist[-1][1] - hist[-2][1])
        data["delta_y"] = None
        for d, v in hist:
            if d == one_year_ago:
                data["delta_y"] = (hist[-1][1] - v)
                break

        # validate
        validate(instance=data, schema=schema)

        # write JSON & CSV
        with open(OUTPUT_DIR / f"{slug}.json", "w") as f:
            json.dump(data, f, indent=2)
        write_csv(slug, hist)
        results[slug] = data

    # daily wrap
    wrap = daily_wrap.generate(results)
    with open(OUTPUT_DIR / "daily_wrap.txt", "w") as f:
        f.write(wrap)

    print("[OK] Published data to", OUTPUT_DIR)
    # Generate PNG charts (spark + full) for each series with history
    try:
        from plotly.graph_objects import Figure, Scatter
        import plotly.graph_objects as go
        from pathlib import Path as _P
        plots_dir = OUTPUT_DIR / "plots"
        plots_dir.mkdir(parents=True, exist_ok=True)
        for slug, d in results.items():
            hist = d.get("history") or []
            if len(hist) < 2:
                continue
            xs = [x for x,_ in hist]
            ys = [y for _,y in hist]
            # Sparkline
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=xs, y=ys, mode="lines", line=dict(width=2)))
            fig.update_layout(margin=dict(l=0,r=0,t=0,b=0), xaxis=dict(visible=False), yaxis=dict(visible=False), width=400, height=80)
            fig.write_image(str(plots_dir / f"{slug}_spark.png"))
            # Full chart
            fig2 = go.Figure()
            fig2.add_trace(go.Scatter(x=xs, y=ys, mode="lines"))
            fig2.update_layout(title=d.get("title",""), xaxis_title="Date", yaxis_title=d.get("unit",""), width=900, height=500)
            fig2.write_image(str(plots_dir / f"{slug}_full.png"))
    except Exception as e:
        print("[WARN] Chart generation failed:", e)

    # If rainfall has a map_url, fetch and store locally
    try:
        import requests as _req
        rf = results.get("rainfall")
        if rf and rf.get("map_url"):
            img = _req.get(rf["map_url"], timeout=20)
            if img.ok:
                (OUTPUT_DIR / "plots").mkdir(parents=True, exist_ok=True)
                with open(OUTPUT_DIR / "plots" / "rainfall_map.png", "wb") as f:
                    f.write(img.content)
    except Exception as e:
        print("[WARN] Rainfall map download failed:", e)

    # Optional: upload to S3 if configured
    s3_bucket = os.getenv("S3_BUCKET")
    if s3_bucket:
        try:
            import boto3
            s3 = boto3.client("s3",
                aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
                aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
                region_name=os.getenv("AWS_DEFAULT_REGION", "ap-southeast-2"))
            prefix = os.getenv("S3_PREFIX", "muster/data")
            # Upload JSON, CSV, and wrap
            for path in (OUTPUT_DIR).glob("*"):
                if path.is_file():
                    s3.upload_file(str(path), s3_bucket, f"{prefix}/{path.name}", ExtraArgs={"ContentType": "application/json" if path.suffix==".json" else "text/plain"})
            for path in (OUTPUT_DIR / "csv").glob("*.csv"):
                s3.upload_file(str(path), s3_bucket, f"{prefix}/csv/{path.name}", ExtraArgs={"ContentType": "text/csv"})
            # plots (if generated by your chart step)
            plots_dir = OUTPUT_DIR / "plots"
            if plots_dir.exists():
                for path in plots_dir.glob("*.*"):
                    s3.upload_file(str(path), s3_bucket, f"{prefix}/plots/{path.name}")
            print("[OK] Uploaded to S3 bucket", s3_bucket)
        except Exception as e:
            print("[WARN] S3 upload failed:", e)


if __name__ == "__main__":
    main()
