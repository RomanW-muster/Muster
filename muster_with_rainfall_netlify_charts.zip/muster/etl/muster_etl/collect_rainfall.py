import os, csv, io, requests
from datetime import datetime, timedelta

# Configure sources:
# BOM_RAINFALL_CSV_URL: CSV with columns like State,Total_mm or Date,State,Total_mm
# BOM_RAINFALL_MAP_URL: PNG/JPG map image URL for 7-day totals
#
# This collector aggregates state totals (last row per state) and reports national sum.

CSV_URL = os.getenv("BOM_RAINFALL_CSV_URL")
MAP_URL = os.getenv("BOM_RAINFALL_MAP_URL")

def _parse(csv_bytes: bytes):
    text = csv_bytes.decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(text))
    totals = {}
    as_of = None
    for row in reader:
        # Try to find keys
        state_key = next((k for k in row if k.lower() in ("state","region","jurisdiction")), None)
        total_key = next((k for k in row if "mm" in k.lower() or "total" in k.lower()), None)
        date_key = next((k for k in row if k.lower() in ("date","as_of","period_end")), None)
        if not (state_key and total_key):
            continue
        st = row[state_key].strip()
        try:
            val = float(row[total_key].strip().replace(",",""))
        except Exception:
            continue
        totals[st] = val
        if date_key and row[date_key].strip():
            as_of = row[date_key].strip()[:10]
    # National sum
    national = sum(totals.values()) if totals else None
    return as_of, totals, national

def run():
    if not CSV_URL:
        # Fallback stub
        today = datetime.utcnow().date().isoformat()
        return {
            "series": "rainfall",
            "value": 0.0,
            "as_of": today,
            "unit": "mm",
            "source_name": "BOM (stub)",
            "source_url": "",
            "calc_notes": "Set BOM_RAINFALL_CSV_URL/BOM_RAINFALL_MAP_URL for live data",
            "history": [],
            "state_totals": {}
        }
    r = requests.get(CSV_URL, timeout=30); r.raise_for_status()
    as_of, state_totals, national = _parse(r.content)
    if not as_of:
        as_of = datetime.utcnow().date().isoformat()
    # Optionally download map to plots directory will be handled in publisher
    return {
        "series": "rainfall",
        "value": round(national or 0.0, 1),
        "as_of": as_of,
        "unit": "mm",
        "source_name": "BOM",
        "source_url": CSV_URL,
        "calc_notes": "National sum of state 7-day totals; map via BOM_RAINFALL_MAP_URL",
        "history": [],
        "state_totals": state_totals,
        "map_url": MAP_URL or ""
    }
