import requests

def latest_audusd():
    try:
        r = requests.get("https://api.exchangerate.host/latest?base=AUD&symbols=USD", timeout=15)
        r.raise_for_status()
        return float(r.json()["rates"]["USD"])
    except Exception:
        return None
