import os, requests
from .fx_util import latest_audusd

# Env config:
# UREA_FOB_USD_URL: optional endpoint returning plain number (USD/t)
# UREA_FOB_USD_FALLBACK: fallback numeric string (e.g., 330)
# UREA_FREIGHT_USD: per-tonne freight USD to AU (e.g., 60)
# UREA_HANDLING_USD: per-tonne ports/handling USD (e.g., 15)

def _get_usd_per_tonne():
    url = os.getenv("UREA_FOB_USD_URL")
    if url:
        r = requests.get(url, timeout=20); r.raise_for_status()
        return float(str(r.text).strip())
    fb = os.getenv("UREA_FOB_USD_FALLBACK", "0")
    return float(fb)

def run():
    fob = _get_usd_per_tonne()  # USD/t
    freight = float(os.getenv("UREA_FREIGHT_USD", "0"))
    handling = float(os.getenv("UREA_HANDLING_USD", "0"))
    landed_usd = fob + freight + handling
    fx = latest_audusd() or 0.65
    # Convert USD/t to AUD/t by dividing by AUDUSD? If 1 AUD = 0.65 USD, then 1 USD = 1/0.65 AUD
    usd_to_aud = 1.0 / fx
    landed_aud_per_t = landed_usd * usd_to_aud
    return {
        "series": "urea",
        "value": round(landed_aud_per_t, 2),
        "as_of": None,  # publisher fills today
        "source_name": "Composite (FOB + freight + handling via env)",
        "source_url": os.getenv("UREA_FOB_USD_URL", ""),
        "calc_notes": f"FOB ${fob:.0f} + freight ${freight:.0f} + handling ${handling:.0f} (USD/t); FX AUDUSD={fx:.4f}",
        "history": []
    }
