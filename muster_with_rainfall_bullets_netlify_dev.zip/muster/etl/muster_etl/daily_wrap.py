def generate(series_map: dict) -> str:
    parts = []
    aud = series_map.get("audusd", {})
    if aud:
        d = aud.get("delta_d")
        val = aud.get("value")
        if d is not None and abs(d) < 0.2:
            parts.append(f"AUD steady around {val:.3f} USD.")
        elif d is not None:
            parts.append(f"AUD/USD {('up' if d>0 else 'down')} to {val:.3f} ({d:+.1f}%).")
    eyci = series_map.get("eyci", {})
    if eyci:
        dd = eyci.get("delta_d")
        val = eyci.get("value")
        if dd is not None:
            parts.append(f"EYCI {('rose' if dd>0 else 'eased')} {dd:+.1f} to {val:.1f} c/kg.")
    # Add more series summaries as needed
    text = " ".join(parts) or "Quiet session across markets."
    return text[:300]


def bullets(series_map: dict) -> list[str]:
    pts = []
    # FX
    aud = series_map.get("audusd", {})
    if aud and aud.get("delta_d") is not None:
        d = aud["delta_d"]
        pts.append(f"AUD/USD {('↑' if d>0 else '↓' if d<0 else '→')} {aud['value']:.3f} ({d:+.2f} d/d)")
    # EYCI
    ey = series_map.get("eyci", {})
    if ey and ey.get("delta_d") is not None:
        pts.append(f"EYCI {('↑' if ey['delta_d']>0 else '↓' if ey['delta_d']<0 else '→')} {ey['value']:.1f} c/kg ({ey['delta_d']:+.1f} d/d)")
    # Urea
    ur = series_map.get("urea", {})
    if ur and ur.get("delta_d") is not None:
        pts.append(f"Urea est. {('↑' if ur['delta_d']>0 else '↓' if ur['delta_d']<0 else '→')} {ur['value']:.0f} AUD/t ({ur['delta_d']:+.2f} d/d)")
    # Diesel
    de = series_map.get("diesel", {})
    if de and de.get("delta_d") is not None:
        pts.append(f"Diesel est. {('↑' if de['delta_d']>0 else '↓' if de['delta_d']<0 else '→')} {de['value']:.3f} AUD/L ({de['delta_d']:+.3f} d/d)")
    # Freight / Rainfall presence
    rf = series_map.get("rainfall", {})
    if rf and rf.get("value") is not None:
        pts.append(f"Rainfall (7‑day nat.): {rf['value']:.1f} mm")
    return pts[:5]
