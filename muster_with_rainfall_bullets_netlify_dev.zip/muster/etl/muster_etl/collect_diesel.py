import os, requests
from .fx_util import latest_audusd

# Diesel proxy method:
# We ingest Singapore 10ppm gasoil benchmark either USD/bbl or USD/t, convert to AUD/L,
# then add a spread to approximate AU retail.
#
# Env:
# DIESEL_BENCH_URL: returns plain number (benchmark price)
# DIESEL_BENCH_UNITS: USD_PER_BBL or USD_PER_TONNE
# DIESEL_RETAIL_SPREAD_AUD_PER_L: e.g., 0.45 (taxes/margins/proxy)
# DIESEL_DENSITY_KG_PER_L: default 0.845

def _get_benchmark():
    url = os.getenv("DIESEL_BENCH_URL")
    if not url:
        return None
    r = requests.get(url, timeout=20); r.raise_for_status()
    return float(str(r.text).strip())

def _usd_to_aud():
    fx = latest_audusd() or 0.65
    return 1.0 / fx

def _usd_per_bbl_to_aud_per_l(usd_per_bbl: float) -> float:
    # 1 barrel = 159 L
    aud_per_usd = _usd_to_aud()
    return (usd_per_bbl * aud_per_usd) / 159.0

def _usd_per_tonne_to_aud_per_l(usd_per_t: float) -> float:
    # Density ~0.845 kg/L => 1 tonne ≈ 1183.43 L
    litres_per_tonne = 1000.0 / float(os.getenv("DIESEL_DENSITY_KG_PER_L", "0.845"))
    aud_per_usd = _usd_to_aud()
    return (usd_per_t * aud_per_usd) / litres_per_tonne

def run():
    bench = _get_benchmark()
    units = (os.getenv("DIESEL_BENCH_UNITS") or "USD_PER_BBL").upper()
    if bench is None:
        # Fallback stub
        bench = 115.0
        units = "USD_PER_BBL"
    if units == "USD_PER_TONNE":
        base_aud_per_l = _usd_per_tonne_to_aud_per_l(bench)
    else:
        base_aud_per_l = _usd_per_bbl_to_aud_per_l(bench)
    spread = float(os.getenv("DIESEL_RETAIL_SPREAD_AUD_PER_L", "0.45"))
    retail_est = base_aud_per_l + spread
    return {
        "series": "diesel",
        "value": round(retail_est, 3),
        "as_of": None,
        "source_name": "Singapore 10ppm gasoil proxy + spread",
        "source_url": os.getenv("DIESEL_BENCH_URL", ""),
        "calc_notes": f"Benchmark {bench} {units}; base {base_aud_per_l:.3f} AUD/L + spread {spread:.3f} = retail est.",
        "history": []
    }
