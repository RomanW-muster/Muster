import requests
from datetime import datetime
SOURCE_URL = "https://api.exchangerate.host/latest?base=AUD&symbols=USD"

def run():
    r = requests.get(SOURCE_URL, timeout=15)
    r.raise_for_status()
    data = r.json()
    rate = float(data["rates"]["USD"])
    date = data.get("date") or datetime.utcnow().strftime("%Y-%m-%d")
    return {
        "series": "audusd",
        "value": round(rate, 6),
        "as_of": date,
        "source_name": "ExchangeRate.host",
        "source_url": "https://exchangerate.host",
        "calc_notes": "Spot AUD→USD from ExchangeRate.host",
        "history": []
    }
