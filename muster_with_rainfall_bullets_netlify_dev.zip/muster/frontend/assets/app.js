async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed ${url}`);
  return res.json();
}

function fmtNumber(x) {
  if (x === null || x === undefined) return "–";
  if (Math.abs(x) >= 1000) return x.toLocaleString(undefined, {maximumFractionDigits: 0});
  return x.toLocaleString(undefined, {maximumFractionDigits: 2});
}

function setDelta(el, value, suffix) {
  if (value === null || value === undefined) { el.textContent = `– ${suffix}`; return; }
  const dir = value >= 0 ? "up" : "down";
  el.classList.remove("up","down");
  el.classList.add(dir);
  const sign = value > 0 ? "+" : "";
  el.textContent = `${sign}${fmtNumber(value)} ${suffix}`;
}

async function renderCard(cardEl) {
  const slug = cardEl.dataset.slug;
  const url = `${window.DATA_BASE_URL}/${slug}.json`;
  try {
    const data = await fetchJSON(url);
    cardEl.querySelector(".value").textContent = fmtNumber(data.value);
    cardEl.querySelector(".unit").textContent = data.unit || "";
    setDelta(cardEl.querySelector(".delta.daily"), data.delta_d, "d/d");
    setDelta(cardEl.querySelector(".delta.yearly"), data.delta_y, "y/y");
    cardEl.querySelector(".asof").textContent = data.as_of;
    cardEl.querySelector(".source").textContent = data.source_name || "";
    if (slug === "rainfall") {
      const mapEl = cardEl.querySelector("img.spark");
      if (mapEl) {
        const mapPath = `${window.DATA_BASE_URL}/plots/rainfall_map.png`;
        mapEl.src = mapPath + `?t=${Date.now()}`; // cache-bust daily
      }
    }
    // Wire downloads
    cardEl.querySelector(".csv").setAttribute("href", `${window.DATA_BASE_URL}/csv/${slug}.csv`);
    cardEl.querySelector(".png").setAttribute("href", `${window.DATA_BASE_URL}/plots/${slug}_full.png`);
  } catch (e) {
    console.error("Card error", slug, e);
  }
}

async function init() {
  // Load daily wrap
  try {
    const wrapRes = await fetch(`${window.DATA_BASE_URL}/daily_wrap.txt`);
    const wrap = await wrapRes.text();
    document.getElementById("daily-wrap").textContent = wrap.trim() || "—";
  } catch {
    document.getElementById("daily-wrap").textContent = "—";
  }

  // Load 'What moved' bullets if available
  try {
    const ptsRes = await fetch(`${window.DATA_BASE_URL}/daily_wrap_points.json`);
    if (ptsRes.ok) {
      const pts = await ptsRes.json();
      const ul = document.getElementById("what-moved");
      if (ul && Array.isArray(pts) && pts.length) {
        ul.innerHTML = pts.map(x => `<li>${x}</li>`).join("");
      }
    }
  } catch {}

  // Render all cards
  document.querySelectorAll(".card[data-slug]").forEach(renderCard);
}

document.addEventListener("DOMContentLoaded", init);
